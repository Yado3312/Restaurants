import sqlite3

class ToolSells: 

    @staticmethod
    def conectar():
        return sqlite3.connect('softRestaurante.db')
    
    # CRUD ventas anuales 
    def leer_ventaAnual():
        conexion = ToolSells.conectar()
        cursor = conexion.cursor()
        cursor.execute("SELECT * FROM ventas_anuales")
        datos = cursor.fetchall()
        return datos
    
    def indert_ventaAnual(totalTarjeta,totalEfectivo):
        conexion = ToolSells.conectar()
        cursor = conexion.cursor()
        cursor.execute("INSERT INTO ventas_anuales (mes, total_ventas_tarjeta, total_ventas_efectivo) VALUES ('Enero', ? , ? )", (totalTarjeta, totalEfectivo))
        conexion.commint()
        conexion.close()

    def delete_ventaAnual(id):
        conexion = ToolSells.conectar()
        cursor = conexion.cursor()
        cursor.execute("DELETE FROM ventas_anuales WHERE id = ? ", (id,))
        conexion.commit()
        conexion.close()

    def update_venta_Anual(ventasTarjeta,ventasEfectivo):
        conexion = ToolSells.conectar()
        cursor = conexion.cursor()
        cursor.execute("UPDATE venta_anual SET total_ventas_tarjeta = ?, total_ventas_efectivo = ?",(ventasTarjeta,ventasEfectivo))
        conexion.commit()
        conexion.close()

    # CRUD ventas diarias

    def leer_ventas_diarias():
        conexion = ToolSells.conectar()
        cursor = conexion.cursor()
        cursor.execute("SELECT * FROM ventas_mensuales")
        datos = cursor.fetchall()
        return datos
    
    def insertar_venta_diaria(totalTarjeta,totalEfectivo):
        conexion = ToolSells.conectar()
        cursor = conexion.cursor()
        cursor.execute("")
        conexion.commit()
        conexion.close()

