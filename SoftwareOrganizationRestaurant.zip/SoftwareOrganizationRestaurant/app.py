from flask import Flask, render_template, request, redirect, url_for
import sqlite3
from controlUsers import ToolUser
from controlEmployees import ToolEmployee
from controlRestaurant import ToolRestaurant



app = Flask(__name__)

datos = ToolUser.create_user()



