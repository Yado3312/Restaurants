import sqlite3

# Tareas: 
# 1.- Hashear las contrasenas

class ToolUser:

    @staticmethod
    def conectar():
        return sqlite3.connect('softRestaurante.db')
    
    # CRUD USUARIOS
    @staticmethod
    def leer_tabla(nombre_tabla):
        conexion = ToolUser.conectar()
        cursor = conexion.cursor()
        cursor.execute(f'SELECT * FROM {nombre_tabla}')
        datos = cursor.fetchall()
        conexion.close()
        return datos
    
    
    def create_user(user_name,age,adress,password):
        conexion = ToolUser.conectar()
        cursor = conexion.cursor()
        cursor.execute("INSERT INTO users (user_name,age,adress,password) VALUES (?,?,?,?)",(user_name,age,adress,password))
        conexion.commit()
        conexion.close()

    def delete_user(user_id):
        conexion = ToolUser.conectar()
        cursor = conexion.cursor()
        cursor.execute("DELETE FROM users WHERE id = ?", (user_id,))
        conexion.commit()
        conexion.close()

    def edit_all_user(user_id,nombre_completo,edad,correo,contrasena):
        conexion = ToolUser.conectar()
        cursor = conexion.cursor()
        cursor.execute("""
        UPDATE usuario 
        SET nombre_completo = ?, edad = ?, correo = ?, contrasena = ? 
        WHERE id = ?
    """,(nombre_completo,edad,correo,contrasena,user_id))
        conexion.commit()
        conexion.close()


    def update_user_name(user_id, nuevo_nombre):
        conexion = ToolUser.conectar()
        cursor = conexion.cursor()
        cursor.execute("UPDATE usuario SET nombre_completo = ? WHERE id = ?", (nuevo_nombre, user_id))
        conexion.commit()
        conexion.close()

    def update_user_email(user_id, nuevo_correo):
        conexion = ToolUser.conectar()
        cursor = conexion.cursor()
        cursor.execute("UPDATE usuario SET correo = ? WHERE id = ?", (nuevo_correo, user_id))
        conexion.commit()
        conexion.close()

    def update_user_password(user_id, nueva_contrasena):
        conexion = ToolUser.conectar()
        cursor = conexion.cursor()
        cursor.execute("UPDATE usuario SET contrasena = ? WHERE id = ?", (nueva_contrasena, user_id))
        conexion.commit()
        conexion.close()

    #Anadimos socios 
    def add_partner(user_id, membership_lvl, benefits):
        conexion = ToolUser.conectar()
        cursor = conexion.cursor()
        cursor.execute("INSERT INTO socios (usuario_id, nivel_membresia, beneficios) VALUES (?,?,?)",(user_id,membership_lvl,benefits))
        conexion.commit()
        conexion.close()


    def delete_partner(user_id):
        conexion = ToolUser.conectar()
        cursor = conexion.cursor()
        cursor.execute("DELETE FROM socios WHERE usuario_id = ?", (user_id,))
        conexion.commit()
        conexion.close()

    