import sqlite3

class ToolEmployee:

    @staticmethod
    def conectar():
        return sqlite3.connect('softRestaurante.db')
    
    #Todos estos son los metodos que se utilizan para interactuar con los emplados.
    @staticmethod
    def read_employees():
        conexion = ToolEmployee.conectar()
        cursor = conexion.cursor()
    
    @staticmethod
    def create_employee(Nombre_Empleado,fecha_contratacion,salario_empleado, puesto_empleado_id,turno_empleado_id):
        conexion = ToolEmployee.conectar()
        cursor = conexion.cursor()
        cursor.execute("INSERT INTO employee (nombre, fecha_contratacion,salario,puesto_id,turno_id) VALUES (?,?,?,?,?)",())

    @staticmethod
    def delete_employee(id):
        conexion = ToolEmployee.conectar()
        cursor = conexion.cursor()
        cursor.execute("DELETE FROM employee WHERE id = ?",(id,))
        conexion.commit()
        conexion.close()


    @staticmethod
    def update_employee(id):
        conexion = ToolEmployee.conectar()
        cursor = conexion.cursor()
        cursor.execute("UPDEATE empleado SET nombre_completo,edad,correo,contrasena where id = ?",(id,))
        conexion.commit()
        conexion.close()


    @staticmethod
    def update_name(nombre,id):
        conexion = ToolEmployee.conectar()
        cursor = conexion.cursor()
        cursor.execute("UPDATE empleado SET nombre_completo = ? WHERE id = ?",(nombre,id))
        conexion.commit()
        conexion.close()


    @staticmethod
    def update_correo(id,nuevo_correo):
        conexion = ToolEmployee.conectar()
        cursor = conexion.cursor()
        cursor.execute("UPDATE empleado SET correo = ? WHERE id = ?",(nuevo_correo,id))
        conexion.commit()
        conexion.close()

    
    @staticmethod
    def update_contraseña(id,contraseña):
        conexion = ToolEmployee.conectar()
        cursor = conexion.cursor()
        cursor.execute("UPDATE empleado SET contrasena = ? WHERE id = ?",(contraseña,id))
        conexion.commit()
        conexion.close()

    @staticmethod
    def update_edad(id,edad):
        conexion = ToolEmployee.conectar()
        cursor = conexion.cursor()
        cursor.execute("UPDATE empleado SET edad = ? WHERE id = ?",(edad,id))
        conexion.commit()
        conexion.close()

    @staticmethod
    def update_direccion(id,direccion):
        conexion = ToolEmployee.conectar()
        cursor = conexion.cursor()
        cursor.execute("UPDATE empleado SET direccion = ? WHERE id = ?",(direccion,id))
        conexion.commit()
        conexion.close()

    @staticmethod
    def update_telefono(id,telefono):
        conexion = ToolEmployee.conectar()
        cursor = conexion.cursor()
        cursor.execute("UPDATE empleado SET telefono = ? WHERE id = ?",(telefono,id))
        conexion.commit()
        conexion.close()

        #Todos estos son los metodos que nos permiten insertar turnos 

        @staticmethod
        def get_turnos():
            conexion = ToolEmployee.conectar()
            cursor = conexion.cursor()
            cursor.execute("SELECT * FROM turnos")
            turnos = cursor.fetchall()


        @staticmethod
        def insertar_turno(nombre,horaInicio,horaFin):
            conexion = ToolEmployee.conectar()
            cursor = conexion.cursor()
            cursor.execute("INSERT INTO turnos (nombre,hora_inicio, hora_fin) VALUES (?,?,?)",(nombre,horaInicio,horaFin))
            conexion.commit()
            conexion.close()

        
        @staticmethod
        def dele_turno(id):
            conexion = ToolEmployee.conectar()
            cursor = conexion.cursor()
            cursor.execute("DELETE FROM turnos WHERE id = ?",(id))
            conexion.commit()
            conexion.close()

        
        @staticmethod
        def update_nombre_turno(nombre,id):
            conexion = ToolEmployee.conectar()
            cursor = conexion.cursor()
            cursor.execute("UPDATE turnos SET nombre = ? WHERE id = ?",(nombre,id))
            conexion.commit()
            conexion.close()


        @staticmethod
        def update_horaInicio_turno(horaInicio,id):
            conexion = ToolEmployee.conectar()
            cursor = conexion.cursor()
            cursor.execute("UPDATE TURNOS SET hora_inicio = ? WHERE id = ?",(horaInicio,id))
            conexion.commit()
            conexion.close()

        @staticmethod
        def update_horaFin_turno(horaFin):
            conexion = ToolEmployee.conectar()
            cursor = conexion.cursor()
            cursor.execute("UPDATE turnos SET hora_fin = ? WHERE id = ?",(horaFin,id))
            conexion.commit()
            conexion.close()
            
        #Todos estos son los metodos que nos permiten insertar tareas

        @staticmethod
        def insertar_tarea(nombre,descripcion,puestoId):
            conexion = ToolEmployee.conectar()
            cursor = conexion.cursor()
            cursor.execute("INSERT INTO tareas (nombre,descripcion,puesto_id) VALUES (?,?,?)",(nombre,descripcion,puestoId))
            conexion.commit()
            conexion.close()

        @staticmethod
        def leer_tareas():
            conexion = ToolEmployee.conectar()
            cursor = conexion.cursor()
            cursor.execute("SELECT * FROM tareas")
            tareas = cursor.fetchall()
            conexion.close()
            return tareas
        
        @staticmethod
        def delete_tarea(id):
            conexion = ToolEmployee.conectar()
            cursor = conexion.cursor()
            cursor.execute("DELETE FROM tareas where id = ?",(id,))
            conexion.commit()
            conexion.close()

        @staticmethod
        def update_tarea(id,nombre,descripion,puestoId):
            conexion = ToolEmployee.conectar()
            cursor = conexion.cursor()
            cursor.execute("UPDATE tares SET nombre = ? descripcion = ? puesto_id? WHERE id = ?",(nombre,descripion,puestoId,id))
            conexion.commit()
            conexion.close()
