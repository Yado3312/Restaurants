import sqlite3

class ToolRestaurant:

    @staticmethod
    def conectar():
        return sqlite3.connect('softRestaurante.db')
    
    # CRUD Categoria
    @staticmethod
    def insertar_seccion(nombreSeccion,descripcionSeccion):
        conexion = ToolRestaurant.conectar()
        cursor = conexion.cursor()
        cursor.execute("INSERT INTO secciones (nombre,descripcion) VALUES (?,?)",(nombreSeccion,descripcionSeccion))
        conexion.commit()
        conexion.close()

    @staticmethod
    def delete_seccion(id):
        conexion = ToolRestaurant.conectar()
        cursor = conexion.cursor()
        cursor.execute("DELETE FROM secciones WHERE id = ?",(id))
        conexion.commit()
        conexion.close()

    @staticmethod
    def update_seccion(nombre,descripcion): 
        conexion = ToolRestaurant.conectar()
        cursor = conexion.cursor()
        cursor.execute("UPDATE secciones SET nombre = ?, descripcion = ? WHERE id = ?",(nombre,descripcion))
        conexion.commit()
        conexion.close()


    @staticmethod
    def leer_seccion():
         conexion = ToolRestaurant.conectar()
         cursor = conexion.cursor()
         cursor.execute("SELECT * FROM secciones")
         categorias = cursor.fetchall()
         conexion.close()
         return categorias
    

    # CRUD PARA LOS PRODUCTOS

    @staticmethod
    def insert_productos(nombre,descripcion,precioCompra,precioVenta,seccionId):
        conexion = ToolRestaurant.conectar()
        cursor = conexion.cursor()
        cursor.execute("INSERT INTO productos (nombre,descripcion,precio_compra,precio_venta,seccion_id)", (nombre,descripcion,precioCompra,precioVenta,seccionId))
        conexion.commit()
        conexion.close()

    @staticmethod
    def delete_productos(id):
        conexion = ToolRestaurant.conectar()
        cursor = conexion.cursor()
        cursor.execute("DELETE FROM productos WHERE id = ?",(id))
        conexion.commit()
        conexion.close()

    @staticmethod
    def update_productos(nombre,descripcion,precioCompra,precioVenta,seccionId,id):
        conexion = ToolRestaurant.conectar()
        cursor = conexion.cursor()
        cursor.execute("UPDATE productos SET nombre = ? descripcion = ? precio_compra = ? precio_venta = ? seccion_id = ? WHERE id = ?",(nombre,descripcion,precioCompra,precioVenta,seccionId,id))
        conexion.commit()
        conexion.close()

    @staticmethod
    def leer_productos():
        conexion = ToolRestaurant.conectar()
        cursor = conexion.cursor()
        cursor.execute("SELECT * FROM productos")
        productos = cursor.fetchall()
        conexion.close()
        return productos
    
    # Movimientos que puda tener el inventario 

    @staticmethod
    def leer_movimientos_inventario():
        conexion = ToolRestaurant.conectar()
        cursor = conexion.cursor()
        cursor.execute("SELECT * FROM movimientos_inventario")
        movimientos = cursor.fetchall()
        conexion.close()
        return movimientos
    
    @staticmethod
    def insert_movimiento_inventario(productoId,seccionId,tipoMovimiento,stock,sobrantes):
        conexion = ToolRestaurant.conectar()
        cursor = conexion.cursor()
        cursor.execute("INSERT INTO movimientos_inventario (producto_id, seccion_id, tipo_movimiento, stock, sobrantes) VALUES(?,?,?,?,?)",(productoId,seccionId,tipoMovimiento,stock,sobrantes))
        conexion.commit()
        conexion.close()

    @staticmethod
    def delete_movimiento_inventario(id):
        conexion = ToolRestaurant.conectar()
        cursor = conexion.cursor()
        cursor.execute("DELETE FROM movimientos_inventario WHERE id = ?",(id))
        conexion.commit()
        conexion.close()    

    @staticmethod
    def update_movimiento_inventario(id,productoId,seccionId,tipoMovimiento,stock,sobrantes):
        conexion = ToolRestaurant.conectar()
        cursor = conexion.cursor()
        cursor.execute("UPDATE movimientos_inventario SET id = ? producto_id = ? seccion_id = id? tipo_movimiento = ? stock = ? sobrantes = ?",(id,productoId,seccionId,tipoMovimiento,stock,sobrantes))
        conexion.commit()
        conexion.close()